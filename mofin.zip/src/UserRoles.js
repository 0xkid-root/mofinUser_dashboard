export const users = [
    { address: "0x0C1ae3Da19858A64C8B7fe9B155EfC3319e6E2cE", isWhitelist: "true",isSmartAccount:"false" },
    { address: "0xBC62bd3FA92626dA061e501c4F13326D6bdf10a8", isWhitelist: "true",isSmartAccount:"false" },
    { address: "0xca25fDa751d83485d40aAc8644E3Ff8211322356", isWhitelist: "false",isSmartAccount:"false"},
    { address: "0x80b7e0aC164690d40b659d23c746248ba159efCc", isWhitelist: "true",isSmartAccount:"false" },
    { address: "0xa6c30deF56Bd84c664a472A608Aeb1017C8f7f9a", isWhitelist: "true",isSmartAccount:"false" },
    { address: "0x32e2B0F829b1Dfb7F55bCE2FC9145640c5a04D78", isWhitelist: "false",isSmartAccount:"false" },
    { address: "0x094365ea4484E2A0077b157e0972149F0C9A10c9", isWhitelist: "true",isSmartAccount:"false" },
    { address: "0x8B92f9628990353A1ef994aE77c8ab45d2b99AF9", isWhitelist: "false",isSmartAccount:"false" },
    { address: "0xE917CBFd0349db369E1d6A0Ccd1449ad365C74D4", isWhitelist: "true",isSmartAccount:"false" },
    { address: "0xBFf3c5ec8b0d983Ec7d10350F7B837Ed632b912c", isWhitelist: "true",isSmartAccount:"false" },
  ];
//   "0x094365ea4484E2A0077b157e0972149F0C9A10c9"
