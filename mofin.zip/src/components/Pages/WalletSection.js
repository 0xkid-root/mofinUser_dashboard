import React from 'react'

const WalletSection = () => {
  return (
    <div className='main-container'>wallet section is here</div>
  )
}

export default WalletSection