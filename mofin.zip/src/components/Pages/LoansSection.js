import React from 'react'

const LoansSection = () => {
  return (
    <div className='main-container'>LoansSection is here:@@@@</div>
  )
}

export default LoansSection