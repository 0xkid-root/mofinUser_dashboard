import React from 'react'

const MarketSection = () => {
  return (
    <div className='main-container'>MarketSection is here</div>
  )
}

export default MarketSection