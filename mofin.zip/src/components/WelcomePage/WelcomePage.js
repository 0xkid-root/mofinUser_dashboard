import React from "react";
import "./WelcomePage.css";
import { usePrivy } from "@privy-io/react-auth";
import { useNavigate } from "react-router-dom";

const WelcomePage = () => {
  const { user, logout } = usePrivy();
  const navigate = useNavigate();
  console.log("user addres is here:", user?.wallet?.address);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(user?.wallet?.address);
    alert("Address copied to clipboard!");
  };

  const handleLoginClick = async (event) => {
    event.preventDefault();
    try {
      await logout();
      setTimeout(() => {
        navigate("/");
      }, 100);
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  const handleTelegramClick = () => {
    window.open("https://t.me/sofinapp", "_blank");
  };

  return (
    <div className="welcome-container">
      <h1>Welcome!</h1>
      <p>
        Welcome! Glad to see you are interested in embarking on your Crypto
        journey with Sofin. We are still in beta and onboarding is whitelisted.
        Please copy your address below.
      </p>
      <div className="address-container">
        <p>{user?.wallet?.address}</p>
        <button className="copy-button" onClick={copyToClipboard}>
          Copy Address
        </button>
      </div>
      <div className="button-container">
        <button className="action-button" onClick={handleLoginClick}>
          Go To Login
        </button>
        <button className="action-button" onClick={handleTelegramClick}>
          Contact To Telegram
        </button>
      </div>
      <p>
        <span className="note">Note:</span> Sofin will never ask for your
        private key.
      </p>
    </div>
  );
};

export default WelcomePage;
